/*
 CopyRigth
*/
 
#include <ConfigurableFirmata.h>
#include "PS2Mouse.h"
#include "FirmataPS2Mouse.h"


boolean FirmataPS2Mouse::handlePinMode(byte pin, int mode)
{
  if (mode == PIN_MODE_PS2MOUSE) {
    // nothing else to do here since the mode is set in PS2MOUSE_CONFIG
      return true;
    }
  return false;
}

void FirmataPS2Mouse::handleCapability(byte pin)
{
  if (IS_PIN_DIGITAL(pin)) {
    Firmata.write(PIN_MODE_PS2MOUSE);
    Firmata.write(1); //1 bits used for digital pin value
  }
}

/*==============================================================================
 * SYSEX-BASED commands
 *============================================================================*/

boolean FirmataPS2Mouse::handleSysex(byte command, byte argc, byte *argv)
{
  if (command == PS2MOUSE_DATA)
  {
    byte mouseCommand, deviceNum, clockPin, dataPin, value;

    mouseCommand = argv[0];
    deviceNum = argv[1];

    if (deviceNum < MAX_MICE)
    {
      if (mouseCommand == PS2MOUSE_CONFIG)
      {
        if (argc < 4 || argc > 5) 
          return false;
        clockPin = argv[2]; 
        dataPin = argv[3];

        if (Firmata.getPinMode(clockPin) == PIN_MODE_IGNORE || Firmata.getPinMode(dataPin) == PIN_MODE_IGNORE)
          return false;
        Firmata.setPinMode(clockPin, PIN_MODE_PS2MOUSE);
        Firmata.setPinMode(dataPin, PIN_MODE_PS2MOUSE);

        if (!mouse[deviceNum])
        {
           numMice++;
        }
        if (argc == 4)
        {
           mouse[deviceNum] = new PS2Mouse(clockPin, dataPin);
        }
        else
        {
          mouse[deviceNum] = new PS2Mouse(clockPin, dataPin, argv[4]);
        }
        _reporting[deviceNum] = false;
        mouse[deviceNum]->initialize();
     }
     else if (mouseCommand == PS2MOUSE_STATUS)
     {
        if (argc != 2)
          return false; 
        MouseStatus status = mouse[deviceNum]->readStatus();
        Firmata.write(START_SYSEX);
        Firmata.write(PS2MOUSE_DATA);
  	   Firmata.write(PS2MOUSE_STATUS);
   	   Firmata.write(deviceNum);
   	   Firmata.sendValueAsTwo7bitBytes(status.status);
  	   Firmata.sendValueAsTwo7bitBytes(status.resolution);
  	   Firmata.sendValueAsTwo7bitBytes(status.samplerate);
  	   Firmata.write(END_SYSEX);
     }
     else if (mouseCommand == PS2MOUSE_DEVICEID)
     {
        if (argc != 2)
          return false; 

        Firmata.write(START_SYSEX);
        Firmata.write(PS2MOUSE_DATA);
        Firmata.write(PS2MOUSE_DEVICEID);
        Firmata.write(deviceNum);
        Firmata.write(mouse[deviceNum]->getDeviceId());
        Firmata.write(END_SYSEX);
     }
     else if (mouseCommand == PS2MOUSE_RESET)
     {
        if (argc != 2)
          return false; 

        mouse[deviceNum]->initialize();
     }
     else if (mouseCommand == PS2MOUSE_SET_RESOLUTION)
     {
        if (argc != 3)
          return false; 

       mouse[deviceNum]->setResolution(argv[2]);
     }
     else if (mouseCommand == PS2MOUSE_SET_FIVE_BUTTONS)
     {
        if (argc != 2)
          return false; 

        mouse[deviceNum]->setFiveButtons();
     }
     else if (mouseCommand == PS2MOUSE_SET_SAMPLE_RATE)
     {
        if (argc != 4)
          return false; 

        mouse[deviceNum]->setSampleRate((int)argv[2] | ((int)argv[3] << 7));
     }
     else if (mouseCommand == PS2MOUSE_REPORTING)
     {
        if (argc != 3)
          return false; 

        _reporting[deviceNum] = (bool)argv[2];
     }
     else if (mouseCommand == PS2MOUSE_SET_STREAM_MODE)
     {
        if (argc != 2)
          return false; 

       mouse[deviceNum]->setStreamMode();
     }
     else if (mouseCommand == PS2MOUSE_SET_REMOTE_MODE)
     {
        if (argc != 2)
          return false; 

       mouse[deviceNum]->setRemoteMode();
     }
     else if (mouseCommand == PS2MOUSE_DATA)
     {
        if (argc != 2)
          return false; 

       send_data(mouse[deviceNum]->readData(), deviceNum);
     }
     else
       return false;
     return true;
    }
    return false;
  }
  return false;
}

void FirmataPS2Mouse::send_data(MouseData data, byte deviceNum)
{
  Firmata.write(START_SYSEX);
  Firmata.write(PS2MOUSE_DATA);
  Firmata.write(PS2MOUSE_DATA);
  Firmata.write(deviceNum);
  Firmata.sendValueAsTwo7bitBytes(data.status);
  Firmata.sendValueAsTwo7bitBytes(data.position.x);
  Firmata.sendValueAsTwo7bitBytes(data.position.y);
  Firmata.sendValueAsTwo7bitBytes(data.wheel);
  Firmata.write(END_SYSEX);
}

/*==============================================================================
 * SETUP()
 *============================================================================*/

void FirmataPS2Mouse::reset()
{
  for (byte i = 0; i < MAX_MICE; i++)
  {
    if (mouse[i])
    {
      free(mouse[i]);
      mouse[i] = 0;
      _reporting[i] = false;
    }
  }
  numMice = 0;
}

/*==============================================================================
 * REPORT()
 *============================================================================*/
void FirmataPS2Mouse::report()
{
  // report mouse data with reporting enabled
  for (byte i = 0; i < MAX_MICE; i++)
  {
    if (_reporting[i] && (mouse[i]) && (mouse[i]->_mode == REMOTE))
    {    
        send_data(mouse[i]->readData(), i);
    }
  }
}



