/*
  FirmataPS2Mouse.h - Firmata library


  See file LICENSE.txt for further informations on licensing terms.

*/

#ifndef FirmataPS2Mouse_h
#define FirmataPS2Mouse_h

#include <ConfigurableFirmata.h>
#include "PS2Mouse.h"
#include "FirmataFeature.h"

    
#define PS2MOUSE_RESET              (0x00)
#define PS2MOUSE_STATUS             (0x01)
#define PS2MOUSE_CONFIG             (0x02)
#define PS2MOUSE_DEVICEID           (0x03)
#define PS2MOUSE_SET_RESOLUTION     (0x04)
#define PS2MOUSE_SET_SAMPLE_RATE    (0X05)
#define PS2MOUSE_REPORTING          (0X06)
#define PS2MOUSE_SET_FIVE_BUTTONS   (0x07)
#define PS2MOUSE_SET_STREAM_MODE    (0X08)
#define PS2MOUSE_SET_REMOTE_MODE    (0x09)
#define PS2MOUSE_DATA			    (0x50)
#define PIN_MODE_PS2MOUSE		    (0x0C)

#define MAX_MICE                    (0x03)



class FirmataPS2Mouse: public FirmataFeature
{
  public:
    boolean handlePinMode(byte pin, int mode);
    boolean _reporting[MAX_MICE];
    void handleCapability(byte pin);
    boolean handleSysex(byte command, byte argc, byte *argv);
    void send_data(MouseData data, byte deviceNum);
    void reset();
    void report();
  private:
    PS2Mouse *mouse[MAX_MICE];
    byte numMice;
};

#endif
