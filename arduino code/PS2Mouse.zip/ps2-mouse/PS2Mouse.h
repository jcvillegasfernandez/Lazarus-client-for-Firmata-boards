#ifndef MOUSE_H_
#define MOUSE_H_


#define REMOTE 1
#define STREAM 0

#define INTELLI_MOUSE 3
#define FIVE_BUTTON_MOUSE 4

#define SCALING_1_TO_1 0xE6
#define SCALING_2_TO_1 0xE7
#define RESOLUTION_8_COUNTS_PER_MM 3

#define SET_RESOLUTION  0xE8
#define REQUEST_DATA    0xEB
#define SET_REMOTE_MODE 0xF0
#define SET_STREAM_MODE 0XEA
#define GET_DEVICE_ID   0xF2
#define SET_SAMPLE_RATE 0xF3
#define RESET           0xFF
#define STATUS_REQUEST  0xE9
#define ENABLE_DATA_REPORTING  0xF4
#define DISABLE_DATA_REPORTING 0xF5

typedef unsigned char byte;

typedef struct {
    byte x, y;
} Position;

typedef struct {
    byte status;
    Position position;
    byte wheel;
} MouseData;

typedef struct {
	byte status;
	byte resolution;
	byte samplerate;
} MouseStatus;

class PS2Mouse {
private:
    byte _clockPin;
    byte _dataPin;
    bool _supportsMouseExtensions;
    bool _initialized;
 
    void high(byte pin);

    void low(byte pin);

    void checkIntelliMouseExtensions();
    
    void setScaling(byte scaling);

    void waitForClockState(byte expectedState);

    byte readByte();

    byte readBit();

    void writeByte(byte data);

    void writeBit(byte bit);

    void enableDataReporting();

    void disableDataReporting();

    void writeAndReadAck(byte data); 
    
public:
    PS2Mouse::PS2Mouse(byte clockPin, byte dataPin, byte mode = REMOTE);

    byte _mode;

    bool _enabled;

    void initialize();
    
    bool dataReady();

    void setFiveButtons();

    void setRemoteMode();

    void setStreamMode();

    byte getDeviceId();

    void setMode(byte data);

    void reset();

    void setResolution(byte resolution);

    void setSampleRate(byte rate);
    
    MouseStatus readStatus();

    MouseData readData();
};

#endif // MOUSE_H_
