#include "PS2Mouse.h"
#include "Arduino.h"


PS2Mouse::PS2Mouse(byte clockPin, byte dataPin, byte mode) {
    _clockPin = clockPin;
    _dataPin = dataPin;
    _supportsMouseExtensions = false;
    _mode = mode;
    _initialized = false;
    _enabled = true;
}

void PS2Mouse::high(byte pin) {
    pinMode(pin, INPUT);
    digitalWrite(pin, HIGH);
}

void PS2Mouse::low(byte pin) {
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
}

void PS2Mouse::initialize() {
    high(_clockPin);
    high(_dataPin);
    delay(20);
    reset();
    delay(20); // Not sure why this needs the delay
    checkIntelliMouseExtensions();
    setResolution(RESOLUTION_8_COUNTS_PER_MM);
    setScaling(SCALING_1_TO_1);
    setSampleRate(60);
    if (_mode == REMOTE) {
      setRemoteMode();
    } else {
      enableDataReporting(); // Tell the mouse to start sending data again
    }
    delayMicroseconds(100);
    _initialized = true;
}

void PS2Mouse::writeByte(byte data) {
    byte parityBit = 1;

    high(_dataPin);
    high(_clockPin);
    delayMicroseconds(300);
    low(_clockPin);
    delayMicroseconds(300);
    low(_dataPin);
    delayMicroseconds(10);
    
    // start bit
    high(_clockPin);
    // wait for mouse to take control of clock)
    waitForClockState(LOW);

    // data
    for (byte i = 0; i < 8; i++) {
        byte dataBit = bitRead(data, i);
        writeBit(dataBit);
        parityBit = parityBit ^ dataBit;
    }

    // parity bit
    writeBit(parityBit);

    // stop bit
    high(_dataPin);
    delayMicroseconds(50);
    waitForClockState(LOW);

    // wait for mouse to switch modes
    while ((digitalRead(_clockPin) == LOW) || (digitalRead(_dataPin) == LOW))
        ;

    // put a hold on the incoming data
    low(_clockPin);
}

void PS2Mouse::writeBit(byte bit) {
    if (bit == HIGH) {
        high(_dataPin);
    } else {
        low(_dataPin);
    }

    waitForClockState(HIGH);
    waitForClockState(LOW);
}

  // function to work with STREAM mode
bool PS2Mouse::dataReady() {
    return (digitalRead(_clockPin) == LOW);
}

byte PS2Mouse::readByte() {
    byte data = 0;

    high(_clockPin);
    high(_dataPin);
    delayMicroseconds(50);
    waitForClockState(LOW);
    delayMicroseconds(5);

    // consume the start bit
    waitForClockState(HIGH);

    // consume 8 bits of data
    for (byte i = 0; i < 8; i++) {
        bitWrite(data, i, readBit());
    }

    // consume parity bit (ignored)
    readBit();

    // consume stop bit
    readBit();

    // put a hold on the incoming data
    low(_clockPin);

    return data;
}

byte PS2Mouse::readBit() {
    waitForClockState(LOW);
    byte bit = digitalRead(_dataPin);
    waitForClockState(HIGH);
    return bit;
}

void PS2Mouse::writeAndReadAck(byte data) {
    writeByte(data);
    readByte();
}

void PS2Mouse::reset() {
    writeAndReadAck(RESET);
    delay(20); // Not sure why this needs the delay
    readByte();  // self-test status
    readByte();  // mouse ID
}

void PS2Mouse::checkIntelliMouseExtensions() {
    // IntelliMouse detection sequence
    setSampleRate(200);
    setSampleRate(100);
    setSampleRate(80);

    byte deviceId = getDeviceId();
    _supportsMouseExtensions = (deviceId == INTELLI_MOUSE);
}

void PS2Mouse::setFiveButtons() {
    // to enter Five buttons mode mouse
    if (_supportsMouseExtensions) {
      setSampleRate(200);
      setSampleRate(200);
      setSampleRate(80);
   
      getDeviceId();
    }
}

// This only effects data reporting in Stream mode.
void PS2Mouse::enableDataReporting() {
  if (!_enabled) {
    writeAndReadAck(ENABLE_DATA_REPORTING);
    _enabled = true;
  }
}

// Disabling data reporting in Stream Mode will make it behave like Remote Mode
void PS2Mouse::disableDataReporting() {
  if (!_enabled) {
    writeAndReadAck(DISABLE_DATA_REPORTING);
    _enabled = false;
  }
}

byte PS2Mouse::getDeviceId() {
    writeAndReadAck(GET_DEVICE_ID);
    return readByte();
}

void PS2Mouse::setSampleRate(byte rate) {
  if (_mode == STREAM) {
    disableDataReporting(); // Tell the mouse to stop sending data.
  }
  writeAndReadAck(SET_SAMPLE_RATE);
  writeAndReadAck(rate);
  if (_mode == STREAM) {
    enableDataReporting(); // Tell the mouse to start sending data again
  }
  delayMicroseconds(100);
}

void PS2Mouse::setScaling(byte scaling) {
    writeAndReadAck(scaling);
}

void PS2Mouse::setRemoteMode() {
   writeAndReadAck(SET_REMOTE_MODE);
   _mode = REMOTE;
}

void PS2Mouse::setStreamMode() {
   writeAndReadAck(SET_STREAM_MODE);
   _mode = STREAM;
}

void PS2Mouse::setResolution(byte resolution) {
    writeAndReadAck(SET_RESOLUTION);
    writeAndReadAck(resolution);
}

void PS2Mouse::setMode(byte data) {
  if (_mode == STREAM) {
    disableDataReporting(); // Tell the mouse to stop sending data.
  }
  writeAndReadAck(data);
  if (_mode == STREAM) {
    enableDataReporting(); // Tell the mouse to start sending data again
  }
  if (_initialized) {
    delayMicroseconds(100);
  }
}

void PS2Mouse::waitForClockState(byte expectedState) {
    while (digitalRead(_clockPin) != expectedState)
        ;
}

MouseStatus PS2Mouse::readStatus() {
    MouseStatus status;

    writeAndReadAck(STATUS_REQUEST);
    status.status = readByte();
    status.resolution = readByte();
    status.samplerate = readByte();

    return status;
}

MouseData PS2Mouse::readData() {
    MouseData data;

    writeAndReadAck(REQUEST_DATA);
    data.status = readByte();
    data.position.x = readByte();
    data.position.y = readByte();

    if (_supportsMouseExtensions) {
        data.wheel = readByte();
    }

    return data;
}
