#ifndef FirmataNeopixels_h
#define FirmataNeopixels_h

#include <ConfigurableFirmata.h>
#include <FirmataFeature.h>
#include <Adafruit_NeoPixel.h>

#define NEOPIXELS_DATA		   (0x51)
#define NEOPIXELS_OFF               (0x00) // set strip to be off
#define NEOPIXELS_CONFIG            (0x01) // configure the strip
#define NEOPIXELS_SHOW              (0x02) // latch the pixels and show them
#define NEOPIXELS_SET_PIXEL         (0x03) // set the color value of pixel n using 4 color 8 bits value, RGBW
#define NEOPIXELS_FADE_RUN_PAUSE    (0x04) // fade run and pause
#define NEOPIXELS_SET_BRIGHTNESS    (0x05) // set brightnes of pixel n
#define NEOPIXELS_SHIFT_CONFIG      (0x06) // shift pixels along the strip
#define NEOPIXELS_FILL_SEGMENT      (0x07) // Fills all or a given start+length of strip. 
#define NEOPIXELS_FADE_CONFIG       (0x08) // progressive pixels color change 
#define NEOPIXELS_SHIFT_RUN         (0x09) // run one step last configured shift
#define NEOPIXELS_FADE_ONE_STEP     (0x0A) // progressive pixels color change, 1 step
#define NEOPIXELS_MOVE_PIXELS       (0x0B) // move pixels from src to dest  
#define PIN_MODE_NEOPIXELS		   (0x0D)

#define MAX_NEOPIXELS			3

class FirmataNeopixels :public FirmataFeature
{
  public:
    // FirmataFeature interface functions. Required for any Firmata plugin.
    bool handlePinMode(byte pin, int mode);
    void handleCapability(byte pin);
    bool handleSysex(byte command, byte argc, byte *argv);
    void reset();
    void update();
    byte deviceNum;
    void fadeSegment(byte deviceNum, bool do_show);
    void shiftSegment(byte deviceNum);
  private:
    boolean color3bytes[MAX_NEOPIXELS];
    uint32_t targetColor[MAX_NEOPIXELS];
    uint16_t _fadePixelStart[MAX_NEOPIXELS];
    uint16_t _fadePixelEnd[MAX_NEOPIXELS];
    uint8_t _fadeLoopsWait[MAX_NEOPIXELS];
    uint16_t _shiftPixelStart[MAX_NEOPIXELS];
    uint16_t _shiftPixelEnd[MAX_NEOPIXELS];    byte fadeShiftRun[MAX_NEOPIXELS];  // bit0 1 = faderun, 0 = pause, bit1=shift right, bit2=shift wrap, bit3=do_show shift
                                       // bits7-4 loops(sampling interval)to wait
    uint32_t calcFade(uint32_t targetColor, uint32_t currentColor);
    void copyPixels(byte deviceNum, uint16_t dest, uint16_t src, uint16_t count);
    Adafruit_NeoPixel *neopixels[MAX_NEOPIXELS];
    byte numNeopixels;

};

#endif
