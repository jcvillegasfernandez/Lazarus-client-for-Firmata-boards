#include <ConfigurableFirmata.h>

#include "FirmataNeopixel.h"

// FirmataFeature interface functions. Required for any Firmata plugin.

boolean FirmataNeopixel::handlePinMode(byte pin, int mode)
{
  if (mode == PIN_MODE_NEOPIXEL)
  {
    // nothing else to do here since the mode is set in NEOPIXEL_CONFIG
    return true;
  }
  return false;
}

void FirmataNeopixel::handleCapability(byte pin)
{
  if (IS_PIN_DIGITAL(pin))
  {
    Firmata.write(PIN_MODE_NEOPIXEL);
    Firmata.write(1); //1 bits used for digital pin value
  }
}

boolean FirmataNeopixel::handleSysex(byte command, byte argc, byte *argv)
{
   if (command == NEOPIXEL_DATA)
   {
      byte pixelCommand;

      if (argc < 2)
        return false;

      pixelCommand = argv[0];
      deviceNum = argv[1];

      if (deviceNum < MAX_NEOPIXELS)
      {
         if (pixelCommand == NEOPIXEL_CONFIG)
         {
           uint8_t pixelPin = (uint8_t)argv[2];

           uint16_t numberLeds = (uint16_t )argv[3] | ((uint16_t )argv[4] << 7);
           neoPixelType ledType = (neoPixelType)((uint16_t )argv[5] | ((uint16_t )argv[6] << 7));

	   if (argc != 7)
             return false;

           if (Firmata.getPinMode(pixelPin) == PIN_MODE_IGNORE)
             return false;
	   Firmata.setPinMode(pixelPin, PIN_MODE_NEOPIXEL);

	   if (neopixels[deviceNum]) free(neopixels[deviceNum]); // it is not new instance

           // new device
           neopixels[deviceNum] = new Adafruit_NeoPixel(numberLeds, pixelPin, ledType);

           color3bytes[deviceNum] = (bool)(((ledType >> 6) & 0b11) == ((ledType >> 4) & 0b11));
           fadeShiftRun[deviceNum] = 0b00001110;  // default, not fade, wrap, right, show, loops to wait (high nibble)
           _fadePixelStart[deviceNum] = 0;
           _fadePixelEnd[deviceNum] = neopixels[deviceNum]->numPixels() - 1;
           _fadeLoopsWait[deviceNum] = 1; // about 25 Hz, eye speed if Sampling interval = 19
           _shiftPixelStart[deviceNum] = 0;
           _shiftPixelEnd[deviceNum] = _fadePixelEnd[deviceNum]; 
           targetColor[deviceNum] = 0;
           neopixels[deviceNum]->clear();
   	   neopixels[deviceNum]->show();
         }
         else if (pixelCommand == NEOPIXEL_OFF)
         {
	   if (argc != 2)
             return false;

           neopixels[deviceNum]->clear();
   	   neopixels[deviceNum]->show();
         }
         else if (pixelCommand == NEOPIXEL_SHOW)
         {
	   if (argc != 2)
             return false;

           neopixels[deviceNum]->show();
         }
         else if (pixelCommand == NEOPIXEL_SET_PIXEL)
         { //  b = bits 7-0, g = bits 15-8, r = bits 23-16, w = bits 31-24 of color, do_show bit32 
           uint16_t pixelNumber = (uint16_t)argv[2] | ((uint16_t)argv[3] << 7);
           uint32_t color =  (uint32_t)argv[4] | ((uint32_t)argv[5] << 7) |  
                    ((uint32_t)argv[6] << 14) | ((uint32_t)argv[7] << 21) |
                    (((uint32_t)argv[8] & 0b1111) << 28) ; 

           //bool do_show = argv[8] & 0b10000; // bit4 =1 show

           if (argc != 9)
             return false;

	   neopixels[deviceNum]->setPixelColor(pixelNumber, color);

           if (argv[8] & 0b10000)  // do_show, bit4 =1 show
             neopixels[deviceNum]->show();
         }
         else if (pixelCommand ==  NEOPIXEL_SHIFT_CONFIG)  
         { 
           if ((argc < 3) || (argc == 4) || (argc == 6) || (argc > 7))
             return false;

           //bool right = argv[2] & 0b1; // bit0 1=right
           //bool wrap = argv[2] & 0b10; // bit1 1=wrap
           //bool do_show = argv[2] & 0b100; // bit2 1=show

           _shiftPixelStart[deviceNum] = 0;
           _shiftPixelEnd[deviceNum] = neopixels[deviceNum]->numPixels() - 1;

           // argc == 3
           fadeShiftRun[deviceNum] = (fadeShiftRun[deviceNum] & 0b11110001) | ((argv[2] << 1) & 0b1110);   

           if (argc > 3) // 5 or 7
           {  
             _shiftPixelStart[deviceNum] = (uint16_t)argv[3] | ((uint16_t)argv[4] << 7); 
           }
  
	   if (argc > 5) // 7, first and end pixels parameters
           {  
             _shiftPixelEnd[deviceNum] = (uint16_t)argv[5] | ((uint16_t)argv[6] << 7); // argc == 7

           } 

           if (_shiftPixelStart[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
             return false;
           if (_shiftPixelEnd[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
             return false;

           // swap Start and End if necessary
           if (_shiftPixelStart[deviceNum] > _shiftPixelEnd[deviceNum])
           {  
             uint16_t swap = _shiftPixelStart[deviceNum];
             _shiftPixelStart[deviceNum] = _shiftPixelEnd[deviceNum];
             _shiftPixelEnd[deviceNum] = swap; 
           }
         }
         else if (pixelCommand ==  NEOPIXEL_FILL_SEGMENT)
         { //  b = bits 7-0, g = bits 15-8, r = bits 23-16, w = bits 31-24 of color, do_show bit32 

           if (argc < 7 || argc > 11)
              return false;

	   uint32_t color =  (uint32_t)argv[2] | ((uint32_t)argv[3] << 7) |  
                    ((uint32_t)argv[4] << 14) | ((uint32_t)argv[5] << 21) |
                    (((uint32_t)argv[6] & 0b1111) << 28); 

           //bool do_show = argv[6] & 0b10000; // bit4 =1 show

           uint16_t first = 0;
           uint16_t end = neopixels[deviceNum]->numPixels() - 1;  

           if (argc == 11)
           {
             end = (uint16_t)argv[9] | ((uint16_t)argv[10] << 7);
             first = (uint16_t)argv[7] | ((uint16_t)argv[8] << 7);
           }
           else if (argc == 9)
             first = (uint16_t)argv[7] | ((uint16_t)argv[8] << 7);
           else if (argc != 7)
             return false; 

           if (first > neopixels[deviceNum]->numPixels() - 1)
             return false;
           if (end > neopixels[deviceNum]->numPixels() - 1)
             return false;

           if (end > first)
             neopixels[deviceNum]->fill(color, first, end - first + 1);
           else
             neopixels[deviceNum]->fill(color, end, first - end + 1);
          
           if (argv[6] & 0b10000)  // if true then show
             neopixels[deviceNum]->show();
         }
         else if (pixelCommand == NEOPIXEL_SET_BRIGHTNESS)
         {// brightness value 0-255, bit0-7, bit8 =1 do_show
           if (argc != 4)
             return false;
           
           neopixels[deviceNum]->setBrightness((uint8_t)(argv[2] | (argv[3] << 7) & 0b1));
           
           //bool do_show = argv[3] & 0b10; // bit1 =1 show

           if (argv[3] & 0b10) // do_show
             neopixels[deviceNum]->show(); 
         }
         else if (pixelCommand == NEOPIXEL_FADE_CONFIG)
         { //  b = bits 7-0, g = bits 15-8, r = bits 23-16, w = bits 31-24 of color
           if (argc < 7 || argc > 12)
              return false;

	   targetColor[deviceNum] =  (uint32_t)argv[2] | ((uint32_t)argv[3] << 7) |  
                    ((uint32_t)argv[4] << 14) | ((uint32_t)argv[5] << 21) |
                    (((uint32_t)argv[6] & 0b1111) << 28);

           _fadePixelStart[deviceNum] = 0;
           _fadePixelEnd[deviceNum] = neopixels[deviceNum]->numPixels() - 1;
           _fadeLoopsWait[deviceNum] = 1; // about 25 Hz, eye speed if Sampling interval = 19
 
           if (argc > 7) // 8, 9, 10, 11 or 12
           {
             if (argc == 8)
               _fadeLoopsWait[deviceNum] = (uint8_t)argv[7] & 0b1111;
             else // 9, 10, 11 or 12
             {
               _fadePixelStart[deviceNum] = (uint16_t)argv[7] | ((uint16_t)argv[8] << 7); // argc == 9
               if (argc > 9) // 10, 11 or 12
               {
                  if (argc == 10)
                    _fadeLoopsWait[deviceNum] = (uint8_t)argv[9] & 0b1111;
                  else // 11 or 12
                  {
                    _fadePixelEnd[deviceNum] = (uint16_t)argv[9] | ((uint16_t)argv[10] << 7); // argc == 11
                    if (argc == 12)
                      _fadeLoopsWait[deviceNum] = (uint8_t)argv[11] & 0b1111;
                  }
               }
             }
           }

           if (_fadePixelStart[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
             return false;
    
           if (_fadePixelEnd[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
             return false;

           // swap Start and End if necessary
           if (_fadePixelStart[deviceNum] > _fadePixelEnd[deviceNum])
           {  
             uint16_t swap = _fadePixelStart[deviceNum];
             _fadePixelStart[deviceNum] = _fadePixelEnd[deviceNum];
             _fadePixelEnd[deviceNum] = swap; 
           }
           fadeShiftRun[deviceNum] &= 0b00001110;   // fade paused
         }
         else if (pixelCommand == NEOPIXEL_FADE_ONE_STEP) // fade run 1 step only 
         {
           if (argc > 3)   
             return false;
           
           fadeShiftRun[deviceNum] &= 0b00001110;   // fade paused
 
           if ((argc == 3) && (argv[2]))  // do_show
             fadeSegment(deviceNum, true);
           else
             fadeSegment(deviceNum, false);                    
         }
         else if (pixelCommand == NEOPIXEL_FADE_RUN_PAUSE) // fade run and pause
         {
           if (argc != 3)   
              return false;
           // bit0 1=fade run 0=pause, bit0 right, bit1=shift wrap, bit2=do_show, bits7-4 loops to wait
           fadeShiftRun[deviceNum] = (fadeShiftRun[deviceNum] & 0b00001110) | (argv[2] & 0b1) |
                                     (_fadeLoopsWait[deviceNum] << 4);
         }
         else if (pixelCommand == NEOPIXEL_SHIFT_RUN) // shift run one step
         {
           if (argc > 3)  
              return false;
	      // bit0 1=fade run 0=pause, bit0 right, bit1=shift wrap, bit2=do_show

           if (argc == 3) // if not argc==3 then run as last time
             fadeShiftRun[deviceNum] = (fadeShiftRun[deviceNum] & 0b11110001) | ((argv[2] << 1) & 0b1110); 
  
           shiftSegment(deviceNum);
           if (fadeShiftRun[deviceNum] & 0b1000) // bit3 do_show
               neopixels[deviceNum]->show();                   
         }
         else if (pixelCommand == NEOPIXEL_MOVE_PIXELS) // move count pixels from src to dest
         {       
           if (argc > 9)  
              return false;
           uint16_t count = 1; // default to 1
           uint16_t src = (uint16_t)argv[2] | ((uint16_t)argv[3] << 7);
           uint16_t dest = (uint16_t)argv[4] | ((uint16_t)argv[5] << 7);

           // swap src and dest if necessary
           if (src > dest)
           {  
             uint16_t swap = src;
             src = dest;
             dest = swap; 
           }
           if (argc > 7) // count argument
             count = (uint16_t)argv[6] | ((uint16_t)argv[7] << 7);
           if (((dest + count) >= neopixels[deviceNum]->numPixels()) || ((src + count) >= neopixels[deviceNum]->numPixels()))
             return false;
           copyPixels(deviceNum, dest, src, count);
           if (((argc == 7) && (argv[6])) || ((argc == 9) && (argv[8]))) // check for show 
               neopixels[deviceNum]->show();                           
         }
         else
           return false;
         return true;
      }
      return false;
   }
   return false;
}

void FirmataNeopixel::shiftSegment(byte deviceNum)
{
  uint32_t saved;

  uint8_t bytesPerPixel = (color3bytes[deviceNum]) ? 3 : 4; // 3=RGB, 4=RGBW
 
  if (_shiftPixelStart[deviceNum] == _shiftPixelEnd[deviceNum])  // nothing to do
    return ;

  // shift Right 
  if (fadeShiftRun[deviceNum] & 0b10)  // bit1 shift right
  {
     if (fadeShiftRun[deviceNum] & 0b100)  // bit2 wrap, save last pixel
        memmove(&saved, neopixels[deviceNum]->getPixels() + bytesPerPixel * _shiftPixelEnd[deviceNum], bytesPerPixel); // save last pixel color
     copyPixels(deviceNum, _shiftPixelStart[deviceNum] + 1, _shiftPixelStart[deviceNum], _shiftPixelEnd[deviceNum] - _shiftPixelStart[deviceNum]); // copy rest of pixels, (deviceNum, start + 1, start, count)
            
     if (fadeShiftRun[deviceNum] & 0b100) //bit2 wrap
        memmove(neopixels[deviceNum]->getPixels() + bytesPerPixel * _shiftPixelStart[deviceNum], &saved, bytesPerPixel); // recover last saved pixel
  }
  else  // shift left
  {
     if (fadeShiftRun[deviceNum] & 0b100)  // bit2 wrap, save first pixel
        memmove(&saved, neopixels[deviceNum]->getPixels() + bytesPerPixel * _shiftPixelStart[deviceNum], bytesPerPixel); // save first pixel color
     copyPixels(deviceNum, _shiftPixelStart[deviceNum], _shiftPixelStart[deviceNum] + 1, _shiftPixelEnd[deviceNum] - _shiftPixelStart[deviceNum]); // copy rest of pixels, (deviceNum, start, start + 1, count)

     if (fadeShiftRun[deviceNum] & 0b100) // bit2 wrap
        memmove(neopixels[deviceNum]->getPixels() + bytesPerPixel * _shiftPixelEnd[deviceNum], &saved, bytesPerPixel); // recover last saved pixel 
  }
}

void FirmataNeopixel::copyPixels(byte deviceNum, uint16_t dest, uint16_t src, uint16_t count)
{
  uint8_t *pixels = neopixels[deviceNum]->getPixels();
  uint8_t bytesPerPixel = (color3bytes[deviceNum]) ? 3 : 4; // 3=RGB, 4=RGBW
  // dest, scr, count
  memmove(pixels + (dest * bytesPerPixel), pixels + (src * bytesPerPixel), count * bytesPerPixel);
}

uint32_t FirmataNeopixel::calcFade(uint32_t targetColor, uint32_t currentColor)
{
    if (targetColor == currentColor)
      return currentColor;
  
    uint8_t target;
    uint8_t current;

    // red
    target = (uint8_t)(targetColor >> 16);
    current = (uint8_t)(currentColor >> 16);
    if (target > current)
      current++;
    else if (target < current)
      current--;

    currentColor = (currentColor & 0xFF00FFFF) | ((uint32_t)current << 16);

    // green
    target = (uint8_t)(targetColor >> 8);
    current = (uint8_t)(currentColor >> 8);
    if (target > current)
      current++;
    else if (target < current) 
      current--;

    currentColor = (currentColor & 0xFFFF00FF) | ((uint32_t)current << 8);

    // blue
    target = (uint8_t)targetColor;
    current = (uint8_t)currentColor;
    if (target > current)
      current++;
    else if (target < current)
      current--;

    currentColor = (currentColor & 0xFFFFFF00) | (uint32_t)current;

    // white
    target = (uint8_t)(targetColor >> 24);
    current = (uint8_t)(currentColor >> 24);
    if (color3bytes[deviceNum]) // only 3 colors
      current = target;
    else
    {
      if (target > current)
        current++;
      else if (target < current) 
        current--; 
    }

    return ((currentColor & 0x00FFFFFF) | ((uint32_t)current << 24)); 
}

void FirmataNeopixel::fadeSegment(byte deviceNum, bool do_show)
{
    bool endfade = true;
    uint32_t currentColor;

    if (_fadePixelStart[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
       _fadePixelStart[deviceNum] = 0;

    if (_fadePixelEnd[deviceNum] > neopixels[deviceNum]->numPixels() - 1)
       _fadePixelEnd[deviceNum] = neopixels[deviceNum]->numPixels() - 1;
   
    // swap Start and End if necessary
    if (_fadePixelStart[deviceNum] > _fadePixelEnd[deviceNum])
    {  
      uint16_t swap = _fadePixelStart[deviceNum];
      _fadePixelStart[deviceNum] = _fadePixelEnd[deviceNum];
      _fadePixelEnd[deviceNum] = swap; 
    }

    for (uint16_t i = _fadePixelStart[deviceNum]; i <= _fadePixelEnd[deviceNum]; i++)
    {
      currentColor = calcFade(targetColor[deviceNum], neopixels[deviceNum]->getPixelColor(i));// calc new color for pixel
      neopixels[deviceNum]->setPixelColor(i, currentColor); // set new pixel color

      if (currentColor != targetColor[deviceNum]) // different color
        endfade = false; // if no pixel has changed then end fade true
    } 
    if (do_show)
      neopixels[deviceNum]->show();

    if (endfade) // none pixel has changed
    { // segment fade end
      fadeShiftRun[deviceNum] &= 0b00001110; //stops fade running

      Firmata.write(START_SYSEX);
      Firmata.write(NEOPIXEL_DATA);
      Firmata.write(NEOPIXEL_FADE_RUN_PAUSE);
      Firmata.write(deviceNum);
      Firmata.write(END_SYSEX);
    }
}

void FirmataNeopixel::reset()
{
  for (byte i = 0; i < MAX_NEOPIXELS; i++)
  {
    if (neopixels[i])
    {
      neopixels[i]->~Adafruit_NeoPixel();
      neopixels[i] = 0;
    }
  }
}

FirmataNeopixel::FirmataNeopixel()
{
  for (int i = 0; i < MAX_NEOPIXELS; i++)
  {
    neopixels[i] = 0;
  }
}

void FirmataNeopixel::report(bool elapsed)  // For compability with new configurablefirmata
{
  if (!elapsed) return;

 for (byte i = 0; i < MAX_NEOPIXELS; i++)
  { // bits7-4 high nibble loops to wait
    // bit0 1 = faderun, 0 = pause, bit1=shift right, bit2=shift wrap, bit3=do_show shift
    if (neopixels[i] && (fadeShiftRun[i] & 0b1)) // fade running
    {
      if (fadeShiftRun[i] >> 4) 
        fadeShiftRun[i] -= 16; // decrement high nibble
      else
      {
        fadeSegment(i, true);
        fadeShiftRun[i] = (fadeShiftRun[i] & 0b1111) | (_fadeLoopsWait[i] << 4); // restart count
      }
    }
  }
}

